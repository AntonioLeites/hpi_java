package de.hpi.javaide.unittest;

public class MyMath {
	
	public int add(int a, int b) {
		return a+b;
	}
	
	public int subtract(int a, int b) {
		return a-b;
	}
	
	public double change(double a, double b) {
		return a - b;
	}
	
}
